README for DocBook XML V4.0

This is DocBook XML V4.0, released 18 May 2000.

See 40chg.txt for information about what has changed since DocBook 3.1.

For more information about DocBook, please see

  http://www.oasis-open.org/docbook/

Please send all questions, comments, concerns, and bug reports to the
DocBook mailing list: docbook@lists.oasis-open.org
